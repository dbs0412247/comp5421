/*
 * QCVTool.cpp
 *
 *  Created on: 13 Mar, 2015
 *      Author: adrian
 */

#include "QCVTool.h"

using namespace cv;
using namespace std;

QCVTool::QCVTool()
{
}

QCVTool::~QCVTool()
{
}

void QCVTool::setImageDirectory(QString qdir)
{

}

void QCVTool::showResultSIFT()
{

}

void QCVTool::showResultSURF()
{

}

void QCVTool::showResultMSER()
{

}

void QCVTool::showResultHaris()
{

}
void QCVTool::showResultRepair()
{

}

void QCVTool::imageDirectoryChanged(QString dir)
{

}

void QCVTool::featuresDetectedAndMatched(QString method)
{

}

void QCVTool::imageRepaired(QImage img)
{

}
